<?php
 class Usuarios
  {
  public $nome;
  public $email;
  public $usuario;
  public $senha;

  function receberDados($conexao)
   {
   $this->nome       = trim($conexao->escape_string($_POST["nome"]));
   $this->email      = trim($conexao->escape_string($_POST["email"]));
   $this->usuario    = trim($conexao->escape_string($_POST["usuario"]));
   $this->senha      = trim($conexao->escape_string($_POST["senha"]));

   $this->senha      = password_hash($this->senha, PASSWORD_ARGON2I);
   }

  function cadastrar($conexao, $nomeDaTabela)
   {
   $sql = "INSERT $nomeDaTabela VALUES(
            null,
            '$this->nome',
            '$this->email',
            '$this->usuario',
            '$this->senha')";

   $conexao->query($sql) or die($conexao->error);
   }

 }