<?php

 class Curso
  {
  public $nome;
  public $duracao;

  //método que cria o construtor personalizado
  function __construct($inicializaNome, $inicializaDuracao)
   {
   $this->nome = $inicializaNome;
   $this->duracao = $inicializaDuracao;
   }

  function classificarCurso()
   {
   //classificar o curso acessando o atributo duracao do objeto
   if($this->duracao <= 1)
    {
    $mensagem = "Curso de curta duração";
    }
   elseif($this->duracao < 4)
    {
    $mensagem = "Curso de média duração";
    }
   else
    {
    $mensagem = "Curso de longa duração";
    }

   return $mensagem;
   }

  //método getter para mostrar o nome do curso
  function mostrarNome() 
   {
   return $this->nome;
   }
  }