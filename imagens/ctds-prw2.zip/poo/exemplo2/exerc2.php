<!DOCTYPE html> 
<html lang="pt-BR"> 
<head> 
  <meta charset="utf-8"> 
  <title> Introdução à POO com PHP </title> 
  <link rel="stylesheet" href="poo.css">
</head> 

<body> 
 <h1> Fundamentos do PHP com POO - exemplo 2 </h1>

 <?php 
  require "exerc2.inc.php";

  //criando dois objetos Curso por meio do método construtor definido na classe
  $objCurso1 = new Curso("CTDS", 3);
  $objCurso2 = new Curso("CSTGTI", 6);

  //utilizar os métodos que recuperam o nome de cada curso e sua classificação
  $classific1 = $objCurso1->classificarCurso();
  $classific2 = $objCurso2->classificarCurso();

  $nome1 = $objCurso1->mostrarNome();
  $nome2 = $objCurso2->mostrarNome();

  echo "<p> Dados dos objetos Curso cadastrados: <br>
            Nome do curso 1 = $nome1 <br>
            Classificação do curso 1 = $classific1 <br> <br>
            
            Nome do curso 2 = $nome2 <br>
            Classificação do curso 2 = $classific2 </p>";
 ?>
 
</body> 
</html> 