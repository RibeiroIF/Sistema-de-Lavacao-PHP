<!DOCTYPE html> 
<html lang="pt-BR"> 
<head> 
  <meta charset="utf-8"> 
  <title> Introdução à POO com PHP </title> 
  <link rel="stylesheet" href="poo.css">
</head> 

<body> 
 <h1> Fundamentos do PHP com POO - exemplo 1 </h1>

 <?php 
  require "exerc1.inc.php";

  //criar um objeto Item
  $objItem1 = new Item();

  //adicionando valores aos atributos do objeto Item
  $objItem1->nome = "Impressora";
  $objItem1->categoria = "Hardware periférico";
  $objItem1->preco = 450.29;

  //invocando o método que mostra a categoria do objeto criado
  $categ = $objItem1->mostrarCategoria();
  echo "<p> Categoria do objeto criado = $categ </p>";

  //invocando o método que mostra o preço atual do item
  $precoAtual = $objItem1->mostrarPreco();
  echo "<p> Preço atual do objeto criado = R$$precoAtual </p>";

  //modificar o preço atual do item
  $objItem1->modificarPreco(500.78);

  //invocando o método que mostra o preço atual do item
  $precoAtual = $objItem1->mostrarPreco();
  echo "<p> Preço modificado do objeto criado = R$$precoAtual </p>";
 ?>
 
</body> 
</html> 